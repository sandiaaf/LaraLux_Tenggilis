<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('products')->insert([
            'name' => 'Suite',
            'hotel_id' => 5,
            'type_room' => 'Single',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        DB::table('products')->insert([
            'name' => 'Deluxe Queen',
            'hotel_id' => 5,
            'type_room' => 'Single Semi Double',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        DB::table('products')->insert([
            'name' => 'Executive',
            'hotel_id' => 5,
            'type_room' => 'Standard Double',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
