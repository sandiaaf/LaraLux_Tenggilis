<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use DB;
use Illuminate\Support\Str;

class HotelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('hotels')->insert([
            'name'=> 'Dothan Inn & Suites',
            'address'=>'3285 Montgomery Hwy',
            'postcode'=>'36303-2108',
            'city'=>'Dothan',
            'state'=>'ALABAMA',
            'country_id'=>1,
            'longitude'=>'1.421.403',
            'latitude'=>'-342.039',
            'phone'=>'16204218000',
            'fax'=>'1 913 727-2777',
            'email'=>'info@yourdomain.com',
            'currency'=>'USD',
            'accommodation_type'=>'Hotel',
            'category'=>'5',
            'web'=>'http://www.yourdomain.com/hotel',
            'type_id'=>2
        ]);

        // DB::table('hotels')->insert([
        //     'name'=> 'Catalina Inn',
        //     'address'=>'2015 McFarland Blvd',
        //     'postcode'=>'35476-2920',
        //     'city'=>'Northport (Tuscaloosa Area)',
        //     'state'=>'ALABAMA',
        //     'country_id'=>1,
        //     'longitude'=>'-99.297',
        //     'latitude'=>'376.062',
        //     'phone'=>'61350233266',
        //     'fax'=>'620/723-2245',
        //     'email'=>'info@yourdomain.com',
        //     'currency'=>'USD',
        //     'accommodation_type'=>'Hotel',
        //     'category'=>'5',
        //     'web'=>'http://www.yourdomain.com/hotel',
        //     'type_id'=>1
        // ]);
        
    }
}
